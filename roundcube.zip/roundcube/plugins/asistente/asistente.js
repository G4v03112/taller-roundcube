if (window.rcmail) {
    rcmail.addEventListener('init', function () {
      rcmail.register_command('asistente.open', function () {
        rcmail.goto_url('plugin.asistente');
      }, true);
    });
  }
  