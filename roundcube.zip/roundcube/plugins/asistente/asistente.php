<?php

class asistente extends rcube_plugin
{
    public $task = 'mail';

    function init()
    {
        $this->add_button(array(
            'type'    => 'link',
            'label'   => 'asistente.asistente',
            'class'   => 'button icon button-asistente',
            'command' => 'asistente',
            'domain'  => 'asistente',
            'title'   => 'Asistente IA',
        ), 'toolbar');        
        
        // Cargar scripts y estilos
        $this->include_script('asistente.js');
        $this->include_stylesheet('asistente.css');

        // Incluir CSS de skin si estamos en el módulo de correo
        if ($this->rc->task == 'mail') {
            $this->include_stylesheet('skins/elastic/asistente.css');
        }

        // Registrar acción
        $this->register_action('plugin.asistente', [$this, 'render_asistente']);
    }

    function render_asistente()
    {
        $rcmail = rcmail::get_instance();

        $rcmail->output->set_pagetitle($this->gettext('asistente'));
        $rcmail->output->send('asistente.asistente');
    }
}
